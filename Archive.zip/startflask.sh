#!/bin/bash

export IPERF_PORT=30955
export IPERF_ADDRESS=10.5.1.2
export REDIS_PORT=30379
export REDIS_HOST=10.5.1.2
export MPORT=9055
export OWPING=/opt/bin/owping

/usr/bin/python3 /home/tnor/5GMediahub/Measurements/Service/nbi_measure.py
